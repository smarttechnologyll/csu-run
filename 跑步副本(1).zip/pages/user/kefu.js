var n = getApp();

Page({
    data: {
        navbarData: {
            showCapsule: 2,
            title: "联系客服"
        },
        navheight: n.globalData.navBarHeight
    },
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});